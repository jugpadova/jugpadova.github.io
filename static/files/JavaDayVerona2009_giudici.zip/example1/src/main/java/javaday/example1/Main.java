package javaday.example1;

import java.io.File;
import java.util.List;
import org.openrdf.elmo.ElmoModule;
import org.openrdf.elmo.ElmoQuery;
import org.openrdf.elmo.sesame.SesameManager;
import org.openrdf.elmo.sesame.SesameManagerFactory;
import org.openrdf.repository.Repository;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.rio.rdfxml.util.OrganizedRDFXMLWriter;
import org.openrdf.sail.memory.MemoryStore;

/**
 * Hello world!
 *
 */
public class Main
  {
    public static void main( String[] args )
      throws Exception
      {
        Repository repository = new SailRepository(new MemoryStore(new File("/tmp/RDFStore")));
        repository.initialize();
        ElmoModule module = new ElmoModule();
        SesameManagerFactory factory = new SesameManagerFactory(module, repository);
        SesameManager em = factory.createElmoManager();

        em.getTransaction().begin();
        GeoLocation genova = new GeoLocation();
        genova.setLatitude(45.0);
        genova.setLongitude(9.0);
        genova.setCode("GE");
        GeoLocation milano = new GeoLocation();
        milano.setLatitude(46.0);
        milano.setLongitude(9.0);
        milano.setCode("MI");

        em.persist(genova);
        em.persist(milano);
        em.getTransaction().commit();

        em.getTransaction().begin();
        String queryString = "PREFIX wgs84: <http://www.w3.org/2003/01/geo/wgs84_pos#>\n" +
                             "SELECT ?location WHERE \n" +
                             "  {\n" +
                             "    ?location a ?type.\n" +
                             "    ?location wgs84:lat ?lat\n" +
                             "  }";
        final ElmoQuery query = em.createQuery(queryString).
                                   setType("type", GeoLocation.class).
                                   setParameter("lat", 45.0);

        final List<GeoLocation> result = query.getResultList();

        for (GeoLocation l : result)
          {
              System.err.println(l);
          }
        
        em.getTransaction().commit();

        final OrganizedRDFXMLWriter wr = new OrganizedRDFXMLWriter(System.err);
        wr.handleNamespace("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
        wr.handleNamespace("rdfs", "http://www.w3.org/2000/01/rdf-schema#");
        wr.handleNamespace("wgs84", "http://www.w3.org/2003/01/geo/wgs84_pos#");
        wr.handleNamespace("forceten", "http://www.tidalwave.it/rdf/geo/2009/02/22#");
        
        em.getConnection().export(wr);
        em.close();

//        EntityManagerFactory factory = Persistence.createEntityManagerFactory("example");
//        EntityManager em = factory.createEntityManager();

      }
  }
