#!/bin/sh

java -cp ../EarContent/lib/hsqldb-1.8.jar org.hsqldb.Server
