/**
 * 
 */
package net.java.dev.esjug.util.ejb3.persistence;

import java.io.Serializable;

import net.java.dev.esjug.util.ejb3.domain.DomainObject;

/**
 * Optional interface for domain objects that may become persistent.
 * 
 * </p><p>
 * Most persistence frameworks (ORM frameworks) suggest that persistent
 * objects have an identifier attribute that works as primary-key in
 * the database. This interface provides access to this attribute.
 * 
 * </p><p>
 * Another suggestion is the inclusion of a versioning attribute for
 * the implementation of optmistic locks for data access. This interface
 * also provides access to this attribute.
 * 
 * </p><p>
 * Furthermore, this interface inherits the concepts from the
 * DomainObject to force the implementation of a good progamming practice:
 * the definition of equals() and hashCode() in all domain classes.
 * 
 * </p><p>
 * A standard implementation is provided by PersistentObjectSupport,
 * implementing Java's standard annotations for persistence.
 * 
 * @see net.java.dev.esjug.util.ejb3.persistence.PersistentObjectSupport
 * @author Vitor Souza (vitorsouza@gmail.com)
 *
 */
public interface PersistentObject<I extends Serializable, V extends Serializable> extends DomainObject {
	/**
	 * Returns the object persistence identifier (primary-key). 
	 * 
	 * @return Object identifier.
	 */
	I getId();

	/**
	 * Returns the versioning attribute (column).
	 * 
	 * @return Versioning attribute.
	 */
	V getVersion();
	
	/**
	 * Checks if the object is persistent.
	 * 
	 * @return <code>true</code> if the object is persistent, <code>false</code> otherwise.
	 */
	boolean isPersistent();
}
