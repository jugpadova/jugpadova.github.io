/** ManageAddressBookServiceBean.java :: Created at 29/08/2007 */
package net.java.dev.esjug.seamdemo.application;

import java.util.SortedSet;
import java.util.TreeSet;

import javax.ejb.Stateless;

import net.java.dev.esjug.seamdemo.domain.Contact;
import net.java.dev.esjug.seamdemo.domain.ContactInformation;
import net.java.dev.esjug.seamdemo.persistence.ContactDAO;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@AutoCreate
@Name("manageAddressBookService")
@Scope(ScopeType.APPLICATION)
@Stateless
public class ManageAddressBookServiceBean implements ManageAddressBookService {
	/** Serialization id. */
	private static final long serialVersionUID = 1L;
	
	@In
	private ContactDAO contactDAO;
	
	/* (non-Javadoc)
	 * @see net.java.dev.esjug.addressbook.application.ManageAddressBookService#addNewContact(net.java.dev.esjug.addressbook.domain.Contact, net.java.dev.esjug.addressbook.domain.ContactInformation)
	 */
	public Contact addContact(Contact contact, ContactInformation information) {
		Contact c = (contact.getId() == null) ? new Contact(contact.getName(), contact.getBirthDate()) : contactDAO.retrieveById(contact.getId());
		ContactInformation i = new ContactInformation(information.getType(), information.getValue());
		c.addContactInformation(i);
		contactDAO.save(c);
		return c;
	}

	/* (non-Javadoc)
	 * @see net.java.dev.esjug.addressbook.application.ManageAddressBookService#listContacts()
	 */
	public SortedSet<Contact> listContacts() {
		SortedSet<Contact> contacts = new TreeSet<Contact>();
		contacts.addAll(contactDAO.retrieveAll());
		return contacts;
	}
}
