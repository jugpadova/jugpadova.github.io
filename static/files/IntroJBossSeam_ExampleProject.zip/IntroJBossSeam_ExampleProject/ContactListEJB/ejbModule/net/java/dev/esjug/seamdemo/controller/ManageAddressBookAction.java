/** ManageAddressBookAction.java :: Created at 29/08/2007 */
package net.java.dev.esjug.seamdemo.controller;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.faces.event.ValueChangeEvent;

import net.java.dev.esjug.seamdemo.application.ManageAddressBookService;
import net.java.dev.esjug.seamdemo.domain.Contact;
import net.java.dev.esjug.seamdemo.domain.ContactInformation;

import org.hsqldb.lib.Set;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.log.Log;

import com.icesoft.faces.component.ext.RowSelectorEvent;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@Name("manageAddressBookAction")
@Scope(ScopeType.SESSION)
public class ManageAddressBookAction {
	/** Logger. */
	@Logger
	private Log log;
	
	/** The service class that provides the business logic. */
	@In
	private ManageAddressBookService manageAddressBookService;

	/** Contact list to display. */
	private SortedSet<Contact> contactList;
	
	/** Contact array: to use with the data table. */
	private SelectableContact[] contactArray;
	
	/** Contact list map that provides autocompletion. */
	private Map<String, Object> contacts = new LinkedHashMap<String, Object>();
	
	/** Contact types to display. */
	private Map<Object, String> types;
	
	/** Input contact. */
	private Contact contact = new Contact();

	/** Input contact information. */
	private ContactInformation information = new ContactInformation();
	
	/** Contact that should be displayed. */
	private Contact selectedContact = new SelectableContact();
	
	/**
	 * Accessor method for contactList attribute.
	 *
	 * @return the contactList
	 */
	public SortedSet<Contact> getContactList() {
		if (contactList == null) contactList = manageAddressBookService.listContacts();
		return contactList;
	}
	
	/**
	 * Accessor method for contactArray attribute.
	 *
	 * @return the contactArray
	 */
	public Object[] getContactArray() {
		if (contactArray == null) {
			SortedSet<Contact> contactList = getContactList(); 
			contactArray = new SelectableContact[contactList.size()];
			int i = 0;
			for (Contact c : contactList) contactArray[i++] = new SelectableContact(c);
		}
		return contactArray; 
	}

	/**
	 * Accessor method for contacts attribute.
	 *
	 * @return the contacts
	 */
	public Map<String, Object> getContacts() {
		return contacts;
	}

	/**
	 * Accessor method for contact attribute.
	 *
	 * @return the contact
	 */
	public Contact getContact() {
		return contact;
	}

	/**
	 * Accessor method for information attribute.
	 *
	 * @return the information
	 */
	public ContactInformation getInformation() {
		return information;
	}
	
	/**
	 * Retrieves all possible contact type values.
	 * 
	 * @return All possible contact type values.
	 */
	public Map<Object, String> getTypes() {
		if (types == null) {
			ResourceBundle contactTypes = Contact.getContactTypes();
			types = new LinkedHashMap<Object, String>();
			for (String type : contactTypes.keySet()) {
				types.put(contactTypes.getObject(type), type);
			}			
		}
		return types;
	}
	
	/**
	 * Action method that adds a new contact to the address book.
	 */
	public void addContact() {
		log.info("Adding contact: #0, #1, #2, #3, #4", contact.getId(), contact.getName(), contact.getBirthDate(), information.getType(), information.getValue());
		Contact c = manageAddressBookService.addContact(contact, information);
		getContactList().add(c);
		contactArray = null;
		FacesMessages.instance().add("#{messages['text.successFullyAddedContact']}", contact.getName());
		contact = new Contact();
		information = new ContactInformation();
	}
	
	/**
	 * Listener method that updates birthDate information on the contact.
	 */
	public void updateContactList(ValueChangeEvent event) {
		// Gets search word.
		String searchWord = event.getNewValue().toString();
		
		// Builds the map for autocomplete display.
		contacts.clear();
		contact.setId(null);
		for (Contact c : getContactList()) {
			if (c.getName().startsWith(searchWord)) contacts.put(c.getName(), c.getId());
			
			// Checks for perfect match.
			if (c.getName().equals(searchWord)) {
				contact.setId(c.getId());
				contact.setName(c.getName());
				contact.setBirthDate(c.getBirthDate());
				
				log.info("Exact match: #0, #1, #2", contact.getId(), contact.getName(), contact.getBirthDate());
			}
		}
	}
	
	/**
	 * Listener method that updates the information on the contact that is being displayed. 
	 */
	public void displayContact(RowSelectorEvent e) {
		selectedContact = null;
		if (e.getRow() != -1) selectedContact = contactArray[e.getRow()];
        //for (SelectableContact c : contactArray) if (c.isSelected()) selectedContact = c;
	}
	
	public ContactInformation[] getSelectedContactInfo() {
		ContactInformation[] infos = null;
		if (selectedContact != null) {
			SortedSet<ContactInformation> infoSet = selectedContact.getContactInfo();
			infos = new ContactInformation[infoSet.size()];
			int i = 0;
			for (ContactInformation info : infoSet) infos[i++] = info;
		}
		return infos;
	}
	
	private class SelectableContact extends Contact {
		private Boolean selected = Boolean.FALSE;
		SelectableContact() { }
		SelectableContact(Contact contact) {
			super(contact.getName(), contact.getBirthDate());
			for (ContactInformation info : contact.getContactInfo()) addContactInformation(info);
		}
		public Boolean getSelected() {
			return selected;
		}
		public void setSelected(Boolean selected) {
			this.selected = selected;
		}
	}
}

