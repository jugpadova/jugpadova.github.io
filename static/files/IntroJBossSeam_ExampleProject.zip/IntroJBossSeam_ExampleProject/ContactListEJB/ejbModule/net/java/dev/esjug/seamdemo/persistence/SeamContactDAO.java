/** SeamContactDAO.java :: Created at 29/08/2007 */
package net.java.dev.esjug.seamdemo.persistence;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import net.java.dev.esjug.seamdemo.domain.Contact;
import net.java.dev.esjug.util.ejb3.persistence.SeamBaseDAO;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@AutoCreate
@Name("contactDAO")
@Scope(ScopeType.APPLICATION)
@Stateless
public class SeamContactDAO extends SeamBaseDAO<Contact> implements ContactDAO {
	/** Serialization id. */
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext
	private EntityManager entityManager;

	/* (non-Javadoc)
	 * @see net.java.dev.esjug.util.ejb3.persistence.SeamBaseDAO#getDomainClass()
	 */
	@Override
	protected Class<Contact> getDomainClass() {
		return Contact.class;
	}

	@Override
	protected EntityManager getEntityManager() {
		return entityManager;
	}

	/*
	 * (non-Javadoc)
	 * @see net.java.dev.esjug.seamdemo.persistence.ContactDAO#retrieveByName(java.lang.String)
	 */
	public Contact retrieveByName(String name) {
		Query query = getEntityManager().createQuery("from Contact c where c.name = ?");
		query.setParameter(0, name);
		return (Contact)query.getSingleResult();
	}
}
