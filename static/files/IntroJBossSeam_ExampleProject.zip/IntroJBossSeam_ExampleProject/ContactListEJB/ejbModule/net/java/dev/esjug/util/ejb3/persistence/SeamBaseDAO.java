package net.java.dev.esjug.util.ejb3.persistence;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.annotations.Transactional;

/**
 * Base class for DAOs that use EJB3 Persistence Context
 * as persistence mechanism, managed by Seam's EntityHome.
 *
 * </p><p>
 * For more information on the DAO pattern, visit:
 * <a href="http://java.sun.com/blueprints/corej2eepatterns/Patterns/DataAccessObject.html" target="_blank">http://java.sun.com/blueprints/corej2eepatterns/Patterns/DataAccessObject.html</a>.
 * 
 * @see net.java.dev.esjug.util.ejb3.persistence.BaseDAO
 * @author Vitor Souza (vitorsouza@gmail.com)
 */
public abstract class SeamBaseDAO<T extends PersistentObject<? extends Serializable, ? extends Serializable>> implements BaseDAO<T> {
	protected abstract EntityManager getEntityManager();
	
	/**
	 * Abstract method to be implemented by subclasses in order to return
	 * the domain class that is persisted by each DAO.
	 * 
	 * @return Domain class that is persisted by DAO subclasses.
	 */
	protected abstract Class<T> getDomainClass();
	
	/* (non-Javadoc)
	 * @see net.java.dev.esjug.util.ejb3.persistence.DAOBase#retrieveAll()
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public Collection<T> retrieveAll() {
		// Uses the Persistence Context to load all objects from a class.
		Query query = getEntityManager().createQuery("from " + getDomainClass().getName());
		return query.getResultList();
	}

	/* (non-Javadoc)
	 * @see net.java.dev.esjug.util.ejb3.persistence.DAOBase#retrieveById(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public T retrieveById(Long id) {
		// Uses the Persistence Context to retrieve an object given its id.
		return (T)getEntityManager().find(getDomainClass(), id);
	}

	/* (non-Javadoc)
	 * @see net.java.dev.esjug.util.ejb3.persistence.DAOBase#save(java.lang.Object)
	 */
	public void save(T object) {
		// Uses the Persistence Context to save an object.
		getEntityManager().persist(object);
	}

	/* (non-Javadoc)
	 * @see net.java.dev.esjug.util.ejb3.persistence.DAOBase#delete(java.lang.Object)
	 */
	public void delete(T object) {
		// Uses the Persistence Context to delete an object.
		getEntityManager().remove(object);
	}
}
