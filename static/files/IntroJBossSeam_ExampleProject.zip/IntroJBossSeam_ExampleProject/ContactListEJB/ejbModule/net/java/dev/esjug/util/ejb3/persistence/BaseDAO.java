package net.java.dev.esjug.util.ejb3.persistence;

import java.io.Serializable;
import java.util.Collection;

/**
 * Base interface for all DAO classes in the system.
 *
 * </p><p>
 * For more information on the DAO pattern, visit:
 * <a href="http://java.sun.com/blueprints/corej2eepatterns/Patterns/DataAccessObject.html" target="_blank">http://java.sun.com/blueprints/corej2eepatterns/Patterns/DataAccessObject.html</a>.
 * 
 * @author Vitor Souza (vitorsouza@gmail.com)
 */
public interface BaseDAO<T extends PersistentObject<? extends Serializable, ? extends Serializable>> {
	/**
	 * Retrieves all objects from the persistent class.
	 * 
	 * @return Collection with all objects from the persistent domain class.
	 */
	Collection<T> retrieveAll();

	/**
	 * Obtains a persistent object given its id.
	 * 
	 * @param id Persistent object's id.
	 * @return The persistent object that has the given id.
	 */
	T retrieveById(Long id);

	/** 
	 * Stores an object in the persistent media.
	 * 
	 * @param objeto The object to store.
	 */
	void save(T objeto);

	/**
	 * Removes an object from the persistent media.
	 * 
	 * @param objeto The object to delete.
	 */
	void delete(T objeto);
}
