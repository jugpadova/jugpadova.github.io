package net.java.dev.esjug.util.web;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

/**
 * Contains utilities that are used by Web pages.
 * 
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@Name("webUtils")
@Scope(ScopeType.APPLICATION)
public class WebUtils {
	private static final String DEFAULT_DECORATOR = "/WEB-INF/decorators/default.xhtml";
	
	/**
	 * Provides the relative path to the decorator that is meant to be used.
	 * @return The path to the decorator.
	 */
	public String getDecoratorPath() {
		return DEFAULT_DECORATOR;
	}
}
