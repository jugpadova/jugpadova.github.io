package net.java.dev.esjug.util.ejb3.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import net.java.dev.esjug.util.ejb3.domain.DomainObjectSupport;

/**
 * Standard implementation for persistent objects, implementing 
 * Java's standard annotations for persistence.
 * 
 * @see net.java.dev.esjug.util.ejb3.persistence.PersistentObject
 * @author Vitor Souza (vitorsouza@gmail.com)
 */
@MappedSuperclass
public abstract class PersistentObjectSupport<I extends Serializable, V extends Serializable> extends DomainObjectSupport implements PersistentObject<I, V> {
	/** Identifier attribute (primary-key). */
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private I id;

	/** Versioning attribute. */
	@Version @Column(nullable = false)
	private V version;

	/**
	 * @return Returns the id.
	 */
	public I getId() {
		return id;
	}

	/**
	 * @param id The id to set.
	 */
	public void setId(I id) {
		this.id = id;
	}

	/**
	 * @return Returns the version.
	 */
	public V getVersion() {
		return version;
	}

	/**
	 * @param versao The version to set.
	 */
	protected void setVersion(V versao) {
		this.version = versao;
	}

	/* (non-Javadoc)
	 * @see net.java.dev.esjug.util.ejb3.persistence.ObjetoPersistente#isPersistente()
	 */
	public boolean isPersistent() {
		return (id != null);
	}
}
