/** ContactInformation.java :: Created at 29/08/2007 */
package net.java.dev.esjug.seamdemo.domain;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;

import net.java.dev.esjug.util.ejb3.persistence.PersistentObjectSupport;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@Entity
public class ContactInformation extends PersistentObjectSupport<Long, Long> implements Comparable<ContactInformation> {
	/** Serialization id. */
	private static final long serialVersionUID = 1L;

	/** Type of contact information. */
	@Basic
	private String type;
	
	/** The contact information. */
	@Column(length = 100)
	private String value;
	
	/** Default constructor. */
	public ContactInformation() { }
	
	/**
	 * Creates a new contact information.
	 *  
	 * @param type Type of information (home phone, work phone, etc.)
	 * @param value The information itself (phone number, email address, etc.) 
	 */
	public ContactInformation(String type, String value) {
		super();
		this.type = type;
		this.value = value;
	}

	/**
	 * Accessor method for type attribute.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Mutator method for type attribute.
	 *
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Accessor method for value attribute.
	 *
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Mutator method for value attribute.
	 *
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return value;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(ContactInformation o) {
		// First, compare by type.
		if (type == null) return 1;
		if ((o == null) || (o.type == null)) return -1;
		int typeCompare = type.compareTo(o.type);
		if (typeCompare != 0) return typeCompare;
		
		// If tied on type, compare values.
		if (value == null) return 1;
		if (o.value == null) return -1;
		return value.compareTo(o.value);
	}
}
