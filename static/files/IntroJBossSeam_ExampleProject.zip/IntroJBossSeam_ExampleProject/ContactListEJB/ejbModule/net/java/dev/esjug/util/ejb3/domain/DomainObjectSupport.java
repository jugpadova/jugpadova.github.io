/**
 * 
 */
package net.java.dev.esjug.util.ejb3.domain;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Implementation of the equals() / hashCode() strategy proposed by
 * the DomainObject interface.
 * 
 * @see net.java.dev.esjug.util.ejb3.domain.DomainObjectSupport
 * @author Vitor Souza (vitorsouza@gmail.com)
 */
@MappedSuperclass
public abstract class DomainObjectSupport implements DomainObject {
	/** Unique Universal Identifier (UUID). */
	@Column(nullable = false, length = 40)
	private String uuid;

	/** Constructor. */
	public DomainObjectSupport() {
		// Generates UUID during object construction.
		uuid = UUID.randomUUID().toString();
	}

	/* (non-Javadoc)
	 * @see br.ufes.inf.labes.util.dominio.ObjetoDominio#getUuid()
	 */
	public String getUuid() {
		return uuid;
	}
	
	/**
	 * Sets the uuid.
	 * 
	 * @param uuid The uuid.
	 */
	protected void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		// Checks if the class is the same.
		if (! getClass().equals(obj.getClass())) return false;
		DomainObjectSupport o = (DomainObjectSupport)obj;
		
		// Checks if the UUID is the same.
		return uuid.equals(o.uuid);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return uuid.hashCode();
	}
}
