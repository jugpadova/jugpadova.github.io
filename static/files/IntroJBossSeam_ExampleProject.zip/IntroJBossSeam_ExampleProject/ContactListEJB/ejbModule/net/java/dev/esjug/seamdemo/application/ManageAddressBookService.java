/** ManageAddressBookService.java :: Created at 29/08/2007 */
package net.java.dev.esjug.seamdemo.application;

import java.util.SortedSet;

import javax.ejb.Local;

import net.java.dev.esjug.seamdemo.domain.ContactInformation;
import net.java.dev.esjug.seamdemo.domain.Contact;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@Local
public interface ManageAddressBookService {
	/**
	 * Returns all contacts registered in the address book.
	 * 
	 * @return Set with all contacts.
	 */
	SortedSet<Contact> listContacts();
	
	/**
	 * Adds a new contact to the address book or a new contact information to an existing contact.
	 * 
	 * @param contact Information about the contact (the person).
	 * @param information Contact information (phone, email, etc.).
	 */
	Contact addContact(Contact contact, ContactInformation information);
}
