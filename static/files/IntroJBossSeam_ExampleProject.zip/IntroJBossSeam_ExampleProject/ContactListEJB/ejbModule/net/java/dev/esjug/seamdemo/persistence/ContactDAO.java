package net.java.dev.esjug.seamdemo.persistence;

import net.java.dev.esjug.seamdemo.domain.Contact;
import net.java.dev.esjug.util.ejb3.persistence.BaseDAO;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
public interface ContactDAO extends BaseDAO<Contact> {
	/**
	 * Retrieve the contact given his name.
	 * 
	 * @param name The name of the contact.
	 * @return The contact with the exact name or <code>null</code>, if no contact with that name exist.
	 */
	Contact retrieveByName(String name);
}
