/** Contact.java :: Created at 28/08/2007 */
package net.java.dev.esjug.seamdemo.domain;

import java.util.Date;
import java.util.ResourceBundle;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Sort;
import org.hibernate.annotations.SortType;

import net.java.dev.esjug.util.ejb3.persistence.PersistentObjectSupport;

/**
 * TODO: comment.
 * @author Vítor Souza (vitorsouza@gmail.com)
 */
@Entity
public class Contact extends PersistentObjectSupport<Long, Long> implements Comparable<Contact> {
	/** Serialization id. */
	private static final long serialVersionUID = 1L;
	
	/** Contact type resource bundle. */
	private static ResourceBundle contactTypes;

	/** Contact's name. */
	@Column(length = 50)
	private String name;
	
	/** Contact's birth date. */
	@Temporal(TemporalType.DATE)
	private Date birthDate;
	
	/** Contact information (phones, email, etc). */
	@OneToMany(cascade = CascadeType.ALL)
	@Sort(type = SortType.NATURAL)
	private SortedSet<ContactInformation> contactInfo;

	/** Default constructor. */
	public Contact() { }
	
	/**
	 * Creates a new contact.
	 * 
	 * @param name Contact's name.
	 * @param birthDate Contact's birth date.
	 */
	public Contact(String name, Date birthDate) {
		this.name = name;
		this.birthDate = birthDate;
	}

	/**
	 * Accessor method for name attribute.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Mutator method for name attribute.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Accessor method for birthDate attribute.
	 *
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Mutator method for birthDate attribute.
	 *
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Accessor method for contactInfo attribute.
	 *
	 * @return the contactInfo
	 */
	public SortedSet<ContactInformation> getContactInfo() {
		return contactInfo;
	}

	/**
	 * Mutator method for contactInfo attribute.
	 *
	 * @param contactInfo the contactInfo to set
	 */
	public void setContactInfo(SortedSet<ContactInformation> contactInfo) {
		this.contactInfo = contactInfo;
	}

	/**
	 * Adds a new contact information to this contact in the address book.
	 * @param information The contact information (phone, email, etc.).
	 */
	public void addContactInformation(ContactInformation information) {
		if (contactInfo == null) contactInfo = new TreeSet<ContactInformation>();
		contactInfo.add(information);
	}

	/**
	 * @return the contactTypes
	 */
	public static ResourceBundle getContactTypes() {
		if (contactTypes == null) contactTypes = ResourceBundle.getBundle("net.java.dev.esjug.seamdemo.domain.ContactTypes");
		return contactTypes;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return name;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Contact o) {
		if (name == null) return 1;
		if ((o == null) || (o.name == null)) return -1;
		return name.compareTo(o.name);
	}
}
