/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.benfante.demo.baseApp.blo;

import java.util.Collection;
import java.util.Iterator;
import org.directwebremoting.ScriptSession;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.directwebremoting.proxy.dwr.Util;
import org.directwebremoting.proxy.scriptaculous.Effect;
import org.springframework.stereotype.Component;

/**
 *
 * @author lucio
 */
@Component
@RemoteProxy(name = "chatBo")
public class ChatBo {

    @RemoteMethod
    public void sendMessage(String nickname, String message) {
        WebContext wctx = WebContextFactory.get();
        String currentPage = wctx.getCurrentPage();
        Collection<ScriptSession> scriptSessions =
                wctx.getScriptSessionsByPage(currentPage);
        Iterator<ScriptSession> iterator = scriptSessions.iterator();
        while (iterator.hasNext()) {
            ScriptSession scriptSession = iterator.next();
            Util util = new Util(scriptSession);
            util.addRows("chatLog", new String[][]{{nickname, message}});
        }
        Effect effect = new Effect(scriptSessions);
        effect.highlight("chatLog");
    }
}
