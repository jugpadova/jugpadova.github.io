package com.benfante.demo.baseApp;

/**
 *
 * @author jacopo
 */
public class PopulateInitialDataContextListener extends org.parancoe.web.PopulateInitialDataContextListener {
    
    public PopulateInitialDataContextListener() {
//        clazzToPopulate.add(Authority.class);
//        clazzToPopulate.add(User.class);
//        clazzToPopulate.add(UserAuthority.class);
        
        
    }
    
}
