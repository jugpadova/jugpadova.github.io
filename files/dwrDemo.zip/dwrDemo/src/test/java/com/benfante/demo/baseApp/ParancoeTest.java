package com.benfante.demo.baseApp;

import com.benfante.demo.baseApp.controllers.HomeController;
import org.parancoe.web.test.BaseTest;
import org.springframework.beans.factory.annotation.Autowired;

public class ParancoeTest extends BaseTest {

    /* test everything has been loaded properly */
    public void testSanity() {
        assertNotNull(getApplicationContext().getBean("dataSource"));
        assertNotNull(getApplicationContext().getBean("transactionManager"));
        assertNotNull(getApplicationContext().getBean("conf"));
        assertNotNull(getApplicationContext().getBean("sessionFactory"));
        assertNotNull(getApplicationContext().getBean("handlerMapping"));
        assertNotNull(getApplicationContext().getBean("messageSource"));
        assertNotNull(getApplicationContext().getBean(
                "hibernateGenericDaoInstrumentationAspect"));

        assertNotNull(getApplicationContext().getBean("viewResolver"));
        assertNotNull(getApplicationContext().getBean("exceptionResolver"));
        assertNotNull(getApplicationContext().getBean("multipartResolver"));
    }

    public void testBo() {
    }
    
    @Autowired
    HomeController homeController;
        
    public void testController() {
        assertNotNull(homeController);
    }
}